package tps.application_transportgui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityValiderOffre extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_valider_offre);
    }
}
